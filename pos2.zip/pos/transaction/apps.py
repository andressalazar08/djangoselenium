from django.apps import AppConfig


class TransactionConfig(AppConfig):
    name = 'transaction'
